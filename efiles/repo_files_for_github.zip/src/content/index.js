// Locked research content. The app reads these files; it never edits them.
// Add each church file here as it is approved (smyrna.json, pergamum.json, ...).
import ephesus from './ephesus.json';

export const CHURCH_ORDER = ['Ephesus', 'Smyrna', 'Pergamum', 'Thyatira', 'Sardis', 'Philadelphia', 'Laodicea'];
export const modules = { Ephesus: ephesus };
