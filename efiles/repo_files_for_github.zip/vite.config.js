import { defineConfig } from 'vite';

// base: './' lets the built dist folder run from a laptop with no internet.
// No new packages required; works with the repository's current package.json.
export default defineConfig({
  base: './',
});
